**Project Description**
Based on WebMatrix.WebData in ASP .NET Web Stack, this project provides MySqlSimpleMembershipProvider and MySqlSimpleRoleProvider for MVC and WCF applications that utilize WebMatrix functionality on mySql database engine.
